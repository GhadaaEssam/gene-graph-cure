import React, { useEffect, useState, useRef } from "react";
import ForceGraph3D from "react-force-graph-3d";
import * as THREE from "three";
import { mockGraphData } from "../mock/mockGraphData";

const GraphVisualization = () => {
  const fgRef = useRef();

  const [graphData, setGraphData] = useState({ nodes: [], links: [] });
  const [selectedNode, setSelectedNode] = useState(null);
  const [focusedNode, setFocusedNode] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    try {
      setLoading(true);
      setGraphData(mockGraphData);
      setError(null);
    } catch (err) {
      setError("Failed to load graph");
    } finally {
      setLoading(false);
    }
  }, []);

  // ================= HEATMAP =================
  const getHeatColor = (score) => {
    if (score >= 0.9) return "#ff0000";
    if (score >= 0.8) return "#ff4d00";
    if (score >= 0.7) return "#ffa500";
    if (score >= 0.6) return "#ffd000";
    return "#94a3b8";
  };

  const getConnectedNodes = (node, links) => {
    const connected = new Set();

    links.forEach((link) => {
      const source = typeof link.source === "object" ? link.source.id : link.source;
      const target = typeof link.target === "object" ? link.target.id : link.target;

      if (source === node.id) connected.add(target);
      if (target === node.id) connected.add(source);
    });

    return connected;
  };

  const resetCamera = () => {
    setFocusedNode(null);
    setSelectedNode(null);

    fgRef.current?.cameraPosition(
      { x: 0, y: 0, z: 300 },
      { x: 0, y: 0, z: 0 },
      1200
    );
  };

  // ================= LOADING =================
  if (loading) return <div style={centerBox()}>Loading...</div>;
  if (error) return <div style={centerBox("#fef2f2", "#b91c1c")}>{error}</div>;

  return (
    <div style={{ display: "flex", gap: "20px", height: "650px" }}>

      {/* ================= GRAPH ================= */}
      <div style={{ flex: 1, position: "relative" }}>

        <button onClick={resetCamera} style={btnStyle}>
          Reset
        </button>

        <ForceGraph3D
          ref={fgRef}
          graphData={graphData}
          backgroundColor="#060f1f"
          d3AlphaDecay={0.02}
d3VelocityDecay={0.3}
nodeOpacity={0.9}
linkDirectionalParticles={2}
linkDirectionalParticleSpeed={0.005}

          // ================= COLOR =================
          nodeColor={(node) => {
            const v = node.vimp || node.score || 0;

            if (focusedNode) {
              const connected = getConnectedNodes(focusedNode, graphData.links);

              if (node.id === focusedNode.id) return "#facc15";
              if (connected.has(node.id)) return "#38bdf8";
              return "#cbd5e1";
            }

            return getHeatColor(v);
          }}

          // ================= SIZE =================
          nodeVal={(node) => {
            const v = node.vimp || node.score || 0.3;

            if (focusedNode && focusedNode.id === node.id) return 35;
            if (focusedNode) return 8;

            return v * 25;
          }}

          // ================= LINKS =================
 linkColor={(link) => {
  const corr = link.correlation ?? 0.5;

  if (corr > 0.85) return "#ef4444";   // strong interaction
  if (corr > 0.7) return "#f97316";    // medium-high
  if (corr > 0.5) return "#3b82f6";    // medium
  return "#94a3b8";                     // weak
}}
linkOpacity={(link) => {
  const c = link.correlation ?? 0.5;
  return 0.2 + c * 0.8;
}}
linkWidth={(link) => {
  const corr = link.correlation ?? link.confidence ?? 0.5;

  // normalize safely
  const min = 0.1;
  const max = 1;

  const normalized = Math.max(min, Math.min(max, corr));

  // scale to visual range
  return 1 + normalized * 7; // 1 → 8 px
}}
         
 // ================= GLOW NODE =================
          nodeThreeObject={(node) => {
  const v = node.vimp || node.score || 0.3;

  const group = new THREE.Group();

  // core sphere
  const core = new THREE.Mesh(
    new THREE.SphereGeometry(v * 6 + 2, 20, 20),
    new THREE.MeshStandardMaterial({
      color: getHeatColor(v),
      emissive: getHeatColor(v),
      emissiveIntensity: v > 0.85 ? 1 : 0.3,
    })
  );

  group.add(core);

  // glow layer
  if (v > 0.8) {
    const glow = new THREE.Mesh(
      new THREE.SphereGeometry(v * 9, 20, 20),
      new THREE.MeshBasicMaterial({
        color: getHeatColor(v),
        transparent: true,
        opacity: 0.15,
      })
    );

    group.add(glow);
  }

  return group;
}}
          // ================= CLICK =================
          onNodeClick={(node) => {
            setSelectedNode(node);
            setFocusedNode(node);

            fgRef.current?.cameraPosition(
              { x: node.x + 120, y: node.y + 120, z: node.z + 120 },
              node,
              1200
            );
          }}

          enableNodeDrag={true}
          enableNavigationControls={true}
          showNavInfo={false}
        />
      </div>

     {/* ================= SIDEBAR ================= */}
<div
  style={{
    width: "340px",
    padding: "18px",
    borderRadius: "16px",
    background: "#ffffff",
    border: "1px solid #e5e7eb",
    boxShadow: "0 6px 18px rgba(0,0,0,0.06)",
    overflowY: "auto",
    
  }}
>
  <h3 style={{ marginBottom: "16px", fontWeight: "700" }}>
    Node Details
  </h3>

  {/* ================= EMPTY STATE ================= */}
  {!selectedNode ? (
    <div style={{ color: "#64748b", lineHeight: "1.6" }}>
      <p style={{ marginBottom: "8px" }}>
        Click on a node to inspect details.
      </p>
      <p style={{ fontSize: "13px" }}>
        You can explore genes, pathways, and drug interactions.
      </p>
    </div>
  ) : (
    <>
      {/* ================= HEADER BADGE ================= */}
      <div style={{ marginBottom: "14px" }}>
        <div
          style={{
            display: "inline-block",
            padding: "4px 10px",
            borderRadius: "999px",
            fontSize: "12px",
            fontWeight: "600",
            background:
              selectedNode.type === "gene"
                ? "#dbeafe"
                : selectedNode.type === "pathway"
                ? "#dcfce7"
                : "#f3e8ff",
            color:
              selectedNode.type === "gene"
                ? "#1d4ed8"
                : selectedNode.type === "pathway"
                ? "#166534"
                : "#6b21a8",
            marginBottom: "10px",
          }}
        >
          {selectedNode.type?.toUpperCase?.() || "NODE"}
        </div>

        <h2 style={{ margin: 0, fontSize: "18px" }}>
          {selectedNode.id}
        </h2>
      </div>

      {/* ================= SCORE / WEIGHT ================= */}
      <div style={{ marginBottom: "14px" }}>
        <strong>Score / Weight</strong>
        <p style={{ margin: "4px 0", color: "#334155" }}>
          {selectedNode.score ??
            selectedNode.weight ??
            "N/A"}
        </p>
      </div>

      {/* ================= DESCRIPTION ================= */}
      {selectedNode.description && (
        <div style={{ marginBottom: "14px" }}>
          <strong>Description</strong>
          <p style={{ margin: "4px 0", color: "#475569" }}>
            {selectedNode.description}
          </p>
        </div>
      )}

      {/* ================= TYPE-SPECIFIC INFO ================= */}
      {selectedNode.type === "gene" && (
        <div style={{ marginBottom: "14px" }}>
          <strong>Gene Info</strong>
          <p style={{ margin: "4px 0", color: "#64748b" }}>
            Gene contribution to drug resistance model.
          </p>
        </div>
      )}

      {selectedNode.type === "pathway" && (
        <div style={{ marginBottom: "14px" }}>
          <strong>Pathway Info</strong>
          <p style={{ margin: "4px 0", color: "#64748b" }}>
            Biological signaling pathway influence.
          </p>
        </div>
      )}

      {selectedNode.type === "drug" && (
        <div style={{ marginBottom: "14px" }}>
          <strong>Drug Info</strong>
          <p style={{ margin: "4px 0", color: "#64748b" }}>
            Therapeutic response association.
          </p>
        </div>
      )}

      {/* ================= HIGH IMPACT BADGE ================= */}
      {selectedNode.highlight && (
        <div
          style={{
            padding: "6px 10px",
            background: "#fee2e2",
            color: "#b91c1c",
            borderRadius: "8px",
            display: "inline-block",
            fontWeight: "600",
            marginBottom: "14px",
          }}
        >
          High Impact Gene
        </div>
      )}

      {/* ================= PUBMED LINK ================= */}
      {selectedNode.type === "gene" && (
        <a
          href={`https://pubmed.ncbi.nlm.nih.gov/?term=${selectedNode.id}`}
          target="_blank"
          rel="noreferrer"
          style={{
            display: "inline-block",
            marginTop: "10px",
            padding: "10px 14px",
            background: "#2563eb",
            color: "white",
            borderRadius: "10px",
            textDecoration: "none",
            fontWeight: "600",
          }}
        >
          View Gene in PubMed
        </a>
      )}
      </>
      )}
    </div>
    </div>
  );
}
// ================= STYLES =================
const btnStyle = {
  position: "absolute",
  top: 10,
  left: 10,
  padding: "8px 12px",
  background: "#111827",
  color: "#fff",
  border: "none",
  borderRadius: "8px",
};

const sidebarStyle = {
  width: "300px",
  padding: "16px",
  background: "#fff",
  borderRadius: "12px",
  border: "1px solid #e5e7eb",
};

const centerBox = (bg = "#f8fafc", color = "#475569") => ({
  height: "650px",
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  background: bg,
  color,
  fontWeight: "600",
});

export default GraphVisualization;